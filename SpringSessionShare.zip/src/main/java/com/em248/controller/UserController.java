package com.em248.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Created by Administrator on 2017/10/31.
 */
@Controller
public class UserController {

    @Autowired
    Environment env;



    @GetMapping(value = {"/", "/index"})
    public String index() {

        return "index";
    }

}
